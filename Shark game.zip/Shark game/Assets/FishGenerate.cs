﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishGenerate : MonoBehaviour
{
    public Transform fishprefab;
    public Transform fishprefab2;
    private double i = 0;
    private double j = 0;
    private int r;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        i = Time.realtimeSinceStartup;

        r = Random.Range(0, 2);

        if ((i - j) > 1)
        {
            if (r == 0)
            {
                var fishtransform = Instantiate(fishprefab) as Transform;
                fishtransform.position = new Vector3(15, Random.Range(-4, 4), -2);
                j = i;
            }
            else if (r == 1)
            {
                var fishtransform = Instantiate(fishprefab2) as Transform;
                fishtransform.position = new Vector3(15, Random.Range(-4, 4), -2);
                j = i;
            }
            
        }
    }
}
