﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public Vector2 speed = new Vector2(10, 10);
    private Vector2 movement;
    private float inputX;
    private float inputY;
    public int score;
    public GameObject menucontainer;
    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1;
    }

    // Update is called once per frame
    void Update()
    {
        inputX = Input.GetAxis("Horizontal");
        inputY = Input.GetAxis("Vertical");

        movement = new Vector2(speed.x * inputX, speed.y * inputY);

        var dist = (transform.position - Camera.main.transform.position).z;

        var leftborder = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, dist)).x;
        var rightborder = Camera.main.ViewportToWorldPoint(new Vector3(1, 0, dist)).x;
        var topborder = Camera.main.ViewportToWorldPoint(new Vector3(0, 0, dist)).y;
        var bottomborder = Camera.main.ViewportToWorldPoint(new Vector3(0, 1, dist)).y;

        transform.position = new Vector3(Mathf.Clamp(transform.position.x, leftborder, rightborder),
                                        Mathf.Clamp(transform.position.y, topborder, bottomborder), transform.position.z);
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        Fish hit = collision.gameObject.GetComponent<Fish>();
        if (hit != null){
            Destroy(hit.gameObject);
            if (hit.gameObject.name == "FishEnemy(Clone)")
            {
                //Destroy(gameObject);
                Time.timeScale = 0;
                menucontainer.SetActive(true);
            }
            else
            {
                PlayerPrefs.SetInt("score", PlayerPrefs.GetInt("score", 0) + 1);
            }
        }
    }
}
